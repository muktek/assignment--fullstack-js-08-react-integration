import React from 'react';

export default class CompanyListings  extends React.Component {

  render(){
    return   <div className="page page--companies">
        <h2>Companies</h2>
        {/* render CompanyCard components here ... */}
      </div>
  }
}
